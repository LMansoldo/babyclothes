# Spec detalhada — Modo Agente: feature flag + registro PF-only

> Data: 2026-07-13 · Destino: `docs/superpowers/specs/`
> Formato: **work packages (WP0–WP8)** autocontidos para delegação a subagentes.
> Cada WP tem: arquivos, código completo ou diff, regras, e Definition of Done (DoD).
> Base visual: `BabyClothes Chat Mocks.dc.html` (telas 01–12). Base de código: monorepo `babyclothes`.

## Regras globais (valem para TODOS os WPs)

1. **Svelte 5 runes**: `$props()`, `$state()`, `$derived()`, `$effect()`, `$bindable()`, `Snippet`. Nunca `export let`.
2. **Sem emojis** em código, strings ou stories. Ícones somente de `lucide-svelte`.
3. **CSS**: custom properties de `@babyclothes/design-system/tokens.css`; BEM `.block__element--modifier`; `<style>` scoped no componente.
4. **Não editar** estes arquivos (somente ler): `RegisterScreen.svelte`, `LoginCard.svelte`, componentes existentes do design system, rotas de catálogo/sell.
5. **Nada é deletado.** Marketplace fica no código, oculto por flag.
6. Componentes **nunca** leem `import.meta.env` ou `PUBLIC_APP_MODE` diretamente — sempre via `flags` (WP1).
7. Todo componente novo do design system tem: `NomeDoComponente.svelte` + `index.ts` + `NomeDoComponente.stories.ts` + `NomeDoComponente.test.ts`, e export em `packages/design-system/src/index.ts`.
8. Rodar ao final de cada WP: `yarn workspace @babyclothes/web check && yarn workspace @babyclothes/web test` (e o equivalente do design-system quando aplicável).
9. Textos via i18n: `$t('chave')` — chaves definidas no WP7. Nunca hardcodar português no componente.

Tokens de referência (de `tokens.css` / mock):
`--color-pk #FF3CAC` · `--color-pk-soft #FFE8F5` · `--color-pk-mid #FF85CC` · `--color-pk-purple #B03EFF` · `--bk #111111` · `--of #F8F5F2` · borda neutra `#EDE9E4` · borda input `#D1D5DB` · texto secundário `#6B7280` · texto terciário `#9CA3AF` · sucesso `#22C55E` · erro `var(--color-error)` / `#EF4444` · fontes `--font-lato`, `--sr` (Cormorant), `--font-londrina`.

Ordem de execução e dependências:

```
WP1 (flags) ──► WP2 (shell/guards) ──► WP8 (QA)
WP1 ──► WP3 (registro PF)
WP4 (DS components) ──► WP5 (onboarding) e WP6 (agente)
WP1 + WP4 ──► WP5, WP6
WP7 (i18n) pode rodar em paralelo; WP3/5/6 dependem das chaves
```

---

## WP0 — Ambiente

**Arquivo novo** `apps/web/.env.agent`:

```bash
PUBLIC_API_URL=http://localhost:4000
PUBLIC_MOCK_DATA=false
PUBLIC_GOOGLE_CLIENT_ID=350255803527-o0hj99i1tnmj82lsb20hokj9lhn2prsf.apps.googleusercontent.com
PUBLIC_APP_MODE=agent
```

**Editar** `apps/web/.env` — acrescentar linha:

```bash
PUBLIC_APP_MODE=full
```

**Editar** `apps/web/package.json` — script novo:

```json
"dev:agent": "dotenv -e .env.agent -- vite dev"
```

(Se `dotenv-cli` não estiver no workspace, adicionar como devDependency.)

**DoD**: `yarn workspace @babyclothes/web dev` sobe em modo full; `dev:agent` sobe em modo agent.

---

## WP1 — Feature flags

### 1.1 Editar `apps/web/src/lib/env.ts` — acrescentar ao final:

```ts
export const PUBLIC_APP_MODE = get('PUBLIC_APP_MODE', 'full')
```

### 1.2 Arquivo novo `apps/web/src/lib/feature-flags.ts` (código completo):

```ts
import { PUBLIC_APP_MODE } from '$lib/env'

export type AppMode = 'full' | 'agent'

export interface FeatureFlags {
  /** Catálogo, detalhe de item, venda, ProductTray, busca no TopBar */
  marketplace: boolean
  /** Registro PJ (CNPJ). false = somente PF */
  pjRegistration: boolean
  /** BottomNav com abas de marketplace */
  marketplaceNav: boolean
  /** Tela /onboarding antes do primeiro acesso ao agente */
  agentOnboarding: boolean
}

export function parseAppMode(raw: string): AppMode {
  return raw === 'agent' ? 'agent' : 'full'
}

export function deriveFlags(mode: AppMode): FeatureFlags {
  const isAgent = mode === 'agent'
  return {
    marketplace: !isAgent,
    pjRegistration: !isAgent,
    marketplaceNav: !isAgent,
    agentOnboarding: isAgent,
  }
}

export const appMode: AppMode = parseAppMode(PUBLIC_APP_MODE)
export const flags: FeatureFlags = deriveFlags(appMode)

/** Prefixos de rota bloqueados quando marketplace=false */
export const MARKETPLACE_ROUTES = ['/catalog', '/sell'] as const

/** Home autenticada conforme o modo */
export const HOME_ROUTE: string = flags.marketplace ? '/catalog' : '/agent'
```

### 1.3 Arquivo novo `apps/web/src/lib/feature-flags.test.ts`:

```ts
import { describe, expect, it } from 'vitest'
import { deriveFlags, parseAppMode } from './feature-flags'

describe('parseAppMode', () => {
  it('retorna agent apenas para "agent"', () => {
    expect(parseAppMode('agent')).toBe('agent')
    expect(parseAppMode('full')).toBe('full')
    expect(parseAppMode('')).toBe('full')
    expect(parseAppMode('banana')).toBe('full')
  })
})

describe('deriveFlags', () => {
  it('modo full liga tudo de marketplace', () => {
    expect(deriveFlags('full')).toEqual({
      marketplace: true,
      pjRegistration: true,
      marketplaceNav: true,
      agentOnboarding: false,
    })
  })
  it('modo agent desliga marketplace e PJ', () => {
    expect(deriveFlags('agent')).toEqual({
      marketplace: false,
      pjRegistration: false,
      marketplaceNav: false,
      agentOnboarding: true,
    })
  })
})
```

**DoD**: testes acima passam; nenhum outro arquivo importa `PUBLIC_APP_MODE` diretamente (grep).

---

## WP2 — Guards de rota e shell

### 2.1 Editar `apps/web/src/hooks.server.ts`

No `handle`, **após** resolver a sessão e **antes** de `resolve(event)`, inserir:

```ts
import { redirect } from '@sveltejs/kit'
import { flags, MARKETPLACE_ROUTES, HOME_ROUTE } from '$lib/feature-flags'

// dentro do handle:
const { pathname } = event.url
if (!flags.marketplace && MARKETPLACE_ROUTES.some((r) => pathname.startsWith(r))) {
  throw redirect(303, HOME_ROUTE)
}
```

Atualizar `hooks.server.test.ts`: caso novo — com `flags.marketplace=false` (mock do módulo `$lib/feature-flags` via `vi.mock`), GET `/catalog` → 303 para `/agent`; com `true`, passa.

### 2.2 Trocar redirects hardcoded `'/catalog'`

Arquivos: `routes/login/+page.server.ts`, `routes/register/+page.server.ts`. Toda ocorrência `redirect(303, '/catalog')` vira `redirect(303, HOME_ROUTE)` com import de `$lib/feature-flags`. **Exceção**: no `register/+page.server.ts`, o redirect de sucesso do modo agent vai para `/onboarding` (ver WP3.4).

### 2.3 Editar `apps/web/src/routes/+layout.svelte`

Mudanças exatas:

1. Import: `import { flags } from '$lib/feature-flags'` e `import AgentTopBar from '$lib/presentation/shell/AgentTopBar.svelte'` (wrapper criado no WP4.5; até lá usar o pattern do DS direto).
2. Rotas sem shell: hoje só `/login`. Passa a: `const bareRoutes = ['/login', '/register', '/onboarding']` — `const isBareRoute = $derived(bareRoutes.some((r) => $page.url.pathname.startsWith(r)))`; o `{#if isLoginRoute}` vira `{#if isBareRoute}`.
3. TopBar:

```svelte
{#if flags.marketplace}
  <TopBar variant={topbarVariant} ... />   <!-- bloco atual, intacto -->
{:else}
  <AgentTopBar
    agentName={$t('agent.topbar.name')}
    status="online"
    unreadCount={$unreadCount}
    userInitials={initials(data.session?.name ?? '')}
    onNotifications={() => goto('/notifications')}
    onProfile={() => goto('/profile')}
  />
{/if}
```

Helper local no script: `function initials(name: string): string { return name.split(' ').filter(Boolean).slice(0, 2).map(p => p[0]!.toUpperCase()).join('') }`.

4. BottomNav: envolver em `{#if flags.marketplaceNav} ... {/if}`. O padding-bottom mobile de `.app-main` (6.4rem) só se aplica com nav — adicionar classe condicional `class:app-main--with-nav={flags.marketplaceNav}` e mover a media query para essa classe.
5. Footer: `{#if flags.marketplace && !isChatRoute}` (modo agent não mostra footer no shell; footer continua nas páginas bare via suas próprias telas se preciso).
6. `isChatRoute` passa a cobrir `/agent`: `$page.url.pathname.startsWith('/chat') || $page.url.pathname.startsWith('/agent')`.

**DoD**: modo full = pixel-idêntico ao atual (nenhum snapshot muda); modo agent = sem BottomNav, sem busca/Publicar, AgentTopBar em todas as rotas autenticadas.

---

## WP3 — Registro PF-only (tela nova)

### 3.1 Arquivo novo `apps/web/src/lib/domain/user/schemas.ts`

```ts
import { z } from 'zod'
import { isValidCpf, stripDocument } from './value-objects/Document'

export const RegisterPFInputSchema = z.object({
  name: z.string().trim().min(2, 'validation.name_required').max(120),
  email: z.string().trim().email('validation.email_invalid').max(254),
  password: z.string().min(8, 'validation.password_min').max(72),
  city: z.string().trim().min(2, 'validation.city_required').max(80),
  cpf: z.string().transform(stripDocument).refine(isValidCpf, 'validation.cpf_invalid'),
})

export type RegisterPFInput = z.infer<typeof RegisterPFInputSchema>
```

(Mensagens são **chaves i18n**, resolvidas na apresentação.)

Teste novo `schemas.test.ts` ao lado: casos — válido completo; CPF com máscara `529.982.247-25` (válido após strip); CPF `111.111.111-11` inválido; email sem `@`; senha 7 chars; cidade vazia. Usar `safeParse` e assert em `success` e `error.issues[0].message`.

### 3.2 Arquivo novo `apps/web/src/lib/presentation/components/RegisterPFScreen.svelte`

Tela **nova e independente** (não importa nada de `RegisterScreen.svelte`). Layout = mock tela 02: header com voltar + "Criar conta"; lead; título Cormorant com em rosa; botão Google; divisor "ou com e-mail"; campos Nome, E-mail, Senha (toggle), Cidade (ícone MapPin + hint); CTA rosa full-width com seta.

Contrato:

```ts
import type { RegisterPFInput } from '$lib/domain/user/schemas'

export interface RegisterPFScreenProps {
  onSubmit: (data: RegisterPFInput) => void
  onGoogleSignIn: () => void
  onBack: () => void
  loading?: boolean
  /** Mensagem já traduzida */
  error?: string
}
```

Esqueleto (estrutura obrigatória; subagente completa estilos seguindo o mock):

```svelte
<script lang="ts">
  import { Button, IconButton, Input } from '@babyclothes/design-system'
  import { ArrowRight, MapPin } from 'lucide-svelte'
  import { t } from '$lib/i18n'
  import { RegisterPFInputSchema, type RegisterPFInput } from '$lib/domain/user/schemas'
  import { formatCpf } from '$lib/domain/user/value-objects/Document'

  let { onSubmit, onGoogleSignIn, onBack, loading = false, error }: RegisterPFScreenProps = $props()

  let name = $state(''); let email = $state(''); let password = $state('')
  let city = $state(''); let cpf = $state('')
  let fieldErrors = $state<Partial<Record<keyof RegisterPFInput, string>>>({})

  function handleCpfInput() { cpf = formatCpf(cpf) }

  function handleSubmit() {
    const parsed = RegisterPFInputSchema.safeParse({ name, email, password, city, cpf })
    if (!parsed.success) {
      fieldErrors = Object.fromEntries(
        parsed.error.issues.map((i) => [i.path[0], $t(String(i.message))]),
      )
      return
    }
    fieldErrors = {}
    onSubmit(parsed.data)
  }
</script>
```

Markup: BEM `registerpf__*` (`__header`, `__heading`, `__lead`, `__title`, `__google`, `__divider`, `__fields`, `__cta`, `__error`). Botão Google: `Button variant="ghost" size="lg"` com SVG do logo Google inline (copiar paths de `LoginCard.svelte`). CTA: `Button variant="pk" size="lg" {loading} onclick={handleSubmit}` com `ArrowRight size={14}`. Cada `Input` recebe `error={fieldErrors.campo}`. Cidade: `hint={$t('auth.register_pf.city_hint')}`.

Largura máx `40rem`, padding `0.8rem 1rem` (igual RegisterScreen).

### 3.3 Editar `apps/web/src/routes/register/+page.svelte`

```svelte
{#if flags.pjRegistration}
  <RegisterScreen onSubmit={handleSubmit} onBack={() => goto('/login')} {loading} error={errorMessage} />
{:else}
  <RegisterPFScreen
    onSubmit={handlePFSubmit}
    onGoogleSignIn={() => goto('/login')}
    onBack={() => goto('/login')}
    {loading}
    error={errorMessage}
  />
{/if}
```

`handlePFSubmit(data: RegisterPFInput)` grava os campos em inputs hidden (form existente ganha os hidden extras `name`, `email`, `password`, `city`, e `type=pf` fixo) e chama `form.requestSubmit()`.

### 3.4 Editar `apps/web/src/routes/register/+page.server.ts`

- `load`: trocar `redirect(303, '/catalog')` por `redirect(303, HOME_ROUTE)`.
- `actions.default`:
  - Se `!flags.pjRegistration && type === 'pj'` → `return fail(400, { error: 'pj_disabled' })`.
  - Modo agent: validar com `RegisterPFInputSchema.safeParse` os campos do form; em falha `return fail(422, { error: 'invalid_document' })` (ou `invalid_fields`).
  - Corpo do POST em modo agent: `{ type: 'pf', cpf, name, email, city }` (senha **só** se o endpoint de registro por e-mail existir — caso contrário omitir e manter fluxo Google; deixar `// TODO(api)` explícito).
  - Sucesso/409: `throw redirect(303, flags.agentOnboarding ? '/onboarding' : HOME_ROUTE)`.
- Atualizar `page.server.test.ts`: casos novos com mock de flags (pj_disabled; sucesso → `/onboarding`).

**DoD**: modo full registra PF/PJ como hoje; modo agent mostra tela nova, valida CPF, rejeita PJ, redireciona a `/onboarding`.

---

## WP4 — Componentes novos do design system

Local: `packages/design-system/src/...`. Seguir regra global 7. Especificação visual = classes do mock (`BabyClothes Chat Mocks.dc.html`).

### 4.1 `composites/ChoiceChipGroup/ChoiceChipGroup.svelte`

```ts
export interface ChoiceChipOption {
  value: string
  label: string
  /** Realce rosa (borda/texto pk) — ex.: opção recomendada */
  primary?: boolean
}
export interface ChoiceChipGroupProps {
  options: ChoiceChipOption[]
  /** Valor selecionado (chip vira fundo pk) */
  value?: string
  onSelect: (value: string) => void
  disabled?: boolean
  ariaLabel: string
  /** outline = chat intake (padrão) · soft = sugestões (fundo pk-soft no primary) */
  tone?: 'outline' | 'soft'
  size?: 'md' | 'sm'
}
```

Render: `<div role="radiogroup" aria-label>` com `<button role="radio" aria-checked>` por opção, `display:flex; gap:0.8rem; flex-wrap:wrap`.

CSS (BEM `.choicechipgroup__chip`):
- base: radius `99rem`; Lato 700; md = padding `0.9rem 1.6rem`, font `.78rem`; sm = `0.9rem 1.4rem`, `.75rem`; fundo `#fff`; borda `1.5px solid #EDE9E4`; cor `#374151`; cursor pointer; transição `background .15s, border-color .15s`.
- `--primary` (tone outline): borda/cor `var(--color-pk)`; sombra `0 2px 8px rgba(255,60,172,.12)`.
- `--primary` (tone soft): fundo `var(--color-pk-soft)`; borda `#FFD0ED`; cor `var(--color-pk)`.
- `--selected` (value === option.value): fundo `var(--color-pk)`; borda transparente; cor `#fff`; sombra `0 2px 8px rgba(255,60,172,.25)`.
- `:disabled`: opacity .5, cursor not-allowed.

Testes: renderiza N chips; click chama `onSelect(value)`; `disabled` não chama; `aria-checked` correto. Story: tone outline (Sim/Não/Bebê a caminho, primeiro primary) e tone soft (5 sugestões).

### 4.2 `composites/AgentFormCard/AgentFormCard.svelte`

```ts
import type { Snippet } from 'svelte'
export interface AgentFormCardProps {
  title: string
  children: Snippet
  maxWidth?: string   // ex. '26rem'; default 100%
}
```

Markup: `<section class="agentformcard" style:max-width>` → header (`display:flex; gap:0.6rem; align-items:center; margin-bottom:1.2rem`) com badge IA + `<h3 class="agentformcard__title">` → `{@render children()}`.

Badge IA (elemento interno, não componente): `inline-flex; gap:0.4rem; padding:0.2rem 0.8rem; radius 99rem; background:var(--bk); color:#fff; font:.6rem 700 var(--font-lato)`; dot `<span>` 5px circle `var(--color-pk)`; texto "IA".

Card: `background:#fff; border:1.5px solid #FFD0ED; border-radius:1.4rem; padding:1.4rem; box-shadow:0 2px 12px rgba(255,60,172,.1)`. Título: `.72rem 700 var(--bk)`.

### 4.3 `composites/MonthPicker/MonthPicker.svelte`

```ts
export interface MonthOption { value: string /* YYYY-MM */; label: string /* 'Out' */ }
export interface MonthPickerProps {
  months: MonthOption[]
  value?: string
  onChange: (value: string) => void
  ariaLabel: string
}
```

Grid `repeat(4, 1fr); gap:0.6rem`. Célula: botão `padding:0.7rem 0; radius 0.8rem; font .72rem 700`; default `background:#F3F4F6; color:#374151`; selecionada `background:var(--color-pk); color:#fff; box-shadow:0 2px 8px rgba(255,60,172,.25)`. `role="radiogroup"`/`radio` como no 4.1.

### 4.4 `patterns/ChildInlineForm/ChildInlineForm.svelte`

Formulário da tela 05, para uso dentro de `AgentFormCard` (e reuso futuro em `/child/register`).

```ts
export interface ChildInlineFormValues {
  name: string
  ageMonths: number | null
  currentHeightCm: number | null
  currentWeightKg: number | null
  birthHeightCm: number | null
  birthWeightG: number | null
}
export interface ChildInlineFormProps {
  initial?: Partial<ChildInlineFormValues>
  loading?: boolean
  submitLabel: string
  labels: {
    name: string; age: string; height: string; weight: string
    birthHeight: string; birthWeight: string
  }
  units?: { age?: string; height?: string; weight?: string; birthHeight?: string; birthWeight?: string }
  onSubmit: (values: ChildInlineFormValues) => void
}
```

Layout: grid `1fr 1fr; gap:1rem`; nome ocupa 2 colunas em telas <480px se necessário (mock usa 2 col sempre — manter 2 col). Campos numéricos com sufixo de unidade: reusar `FormField`/`Input` do DS se suportarem sufixo; senão, marcação própria `.childinlineform__group` (`display:flex; border:1.5px solid #D1D5DB; radius 0.8rem; overflow:hidden`) com `<input type="number">` + `<span class="childinlineform__suffix">` (`background:#F3F4F6; font:.65rem 700; border-left:1.5px solid #D1D5DB; padding:0.9rem 0.8rem`). Labels: `.68rem 700 #374151; margin-bottom:0.4rem`. CTA: `Button variant="pk"` full-width, `disabled` até nome + idade preenchidos. Unidades default: meses/cm/kg/cm/g.

Validação: apenas UI (required/min=0); validação de domínio fica no chamador com `CreateChildInputSchema` (WP6.2).

### 4.5 `patterns/AgentTopBar/AgentTopBar.svelte`

```ts
export interface AgentTopBarProps {
  agentName: string
  status: 'online' | 'typing' | 'offline'
  statusLabel: string          // texto traduzido: 'online' etc.
  statusDetail?: string        // ex. '· Sofia: M'
  unreadCount?: number
  userInitials: string
  onNotifications: () => void
  onProfile: () => void
}
```

Estrutura (mock `.chat-topbar`): container `position:sticky; top:0; z-index:100; background:rgba(255,255,255,.95); backdrop-filter:blur(12px); border-bottom:1px solid #F3F4F6; padding:0.9rem 1.4rem; display:flex; align-items:center; gap:1rem`.
- Esquerda (flex:1): avatar do agente = círculo 32px `var(--bk)` com SVG droplet (`viewBox="0 0 20 24"`, path do logo, fill `var(--color-pk)`, 12×15) + `DotIndicator` verde 8px, borda branca 2px, pulsante quando `status !== 'offline'`; coluna nome (`.8rem 700`) e status (`.62rem 700; cor #22C55E` online / `#9CA3AF` offline) + `statusDetail` em `#9CA3AF`.
- Direita: `IconButton` sino (badge `CountBadge` se `unreadCount > 0`, dot rosa posição absoluta) e `Avatar size="sm" fill="pk"` com `userInitials`, clicável (`onProfile`).

Teste: clicks chamam callbacks; badge só com unread>0; droplet presente.

### 4.6 `patterns/OnboardingHero/OnboardingHero.svelte`

```ts
export interface OnboardingFeature {
  icon: 'size' | 'age' | 'weight' | 'location'
  label: string
}
export interface OnboardingHeroProps {
  title: string          // pode conter <em> — usar {@html} NÃO; receber duas partes:
  titleAccent?: string   // trecho em itálico rosa
  description: string
  features: OnboardingFeature[]
}
```

Conteúdo: SVG ilustrativo **copiado literalmente da tela 03 do mock** (`viewBox="0 0 240 200"`: círculos de glow, droplet com rosto, 4 cards orbitais — body/régua/balança/pin — linhas tracejadas e sparkles). Abaixo, título Cormorant 300 (accent `<em>` rosa), descrição `.8rem` translúcida, grid 2×2 de pills (`background:rgba(255,255,255,.08); border:1px solid rgba(255,255,255,.12); radius 1rem; padding:0.9rem 1.2rem`) com ícone lucide correspondente (`Ruler`, `Clock`, `Gauge`, `MapPin`) em `var(--color-pk-mid)`.

O componente assume fundo escuro (gradiente fica na página, WP5).

### 4.7 Exports — editar `packages/design-system/src/index.ts`

```ts
export { ChoiceChipGroup } from './composites/ChoiceChipGroup/index.js'
export type { ChoiceChipOption } from './composites/ChoiceChipGroup/index.js'
export { AgentFormCard } from './composites/AgentFormCard/index.js'
export { MonthPicker } from './composites/MonthPicker/index.js'
export type { MonthOption } from './composites/MonthPicker/index.js'
// patterns/index.ts:
export { AgentTopBar } from './AgentTopBar/index.js'
export { ChildInlineForm } from './ChildInlineForm/index.js'
export { OnboardingHero } from './OnboardingHero/index.js'
```

**DoD**: 6 componentes com stories visíveis no Storybook, testes passando, exports funcionando via `import { X } from '@babyclothes/design-system'`.

---

## WP5 — Rota /onboarding

**Arquivos novos**: `apps/web/src/routes/onboarding/+page.svelte` e `+page.server.ts`.

`+page.server.ts`:

```ts
import { redirect } from '@sveltejs/kit'
import { flags, HOME_ROUTE } from '$lib/feature-flags'
import type { PageServerLoad } from './$types'

export const load: PageServerLoad = async ({ locals }) => {
  if (!locals.session) throw redirect(303, '/login')
  if (!flags.agentOnboarding) throw redirect(303, HOME_ROUTE)
  return {}
}
```

`+page.svelte`: página bare (sem shell — WP2.2 item 2). Fundo `linear-gradient(160deg,#0F0F0F 0%,#1A0814 60%,#0A0A1A 100%)`, min-height 100vh, conteúdo centrado max-width 40rem. Topo: link "Pular" (`.72rem 700; rgba(255,255,255,.4)`) → `finish()`. Corpo: `<OnboardingHero>` com chaves i18n. Rodapé: `Button variant="pk" size="lg"` full-width `onboarding.cta` + `ArrowRight` → `finish()`.

```ts
const KEY = 'bc_onboarded'
function finish() {
  try { localStorage.setItem(KEY, '1') } catch {}
  goto('/agent')
}
```

Guard client-side no `onMount`/`$effect`: se `localStorage.getItem(KEY) === '1'` → `goto('/agent')` (replaceState).

**DoD**: registro em modo agent cai no onboarding uma única vez; "Pular" e CTA levam a `/agent`; recarregar `/onboarding` depois de visto redireciona.

---

## WP6 — Rota /agent (intake + chat)

### 6.1 Tipos de mensagem — editar `apps/web/src/lib/domain/chat/entities/Message.ts`

Substituir o type `ComponentPayload` por união discriminada, **preservando** os três formatos atuais como interfaces nomeadas (mesmos campos de hoje):

```ts
export interface CarouselPayload { type: 'carousel'; items?: Item[]; label?: string }
export interface ItemListPayload { type: 'itemList'; items?: Item[]; label?: string }
export interface GrowthAlertPayload {
  type: 'growthAlert'
  childName?: string; currentSize?: string; nextSize?: string
  daysUntil?: number; progress?: number; eyebrow?: string; description?: string
  sizes?: { label: string; status: 'past' | 'current' | 'next' | 'future' }[]
  primaryAction?: { label: string; onclick: () => void }
  secondaryAction?: { label: string; onclick: () => void }
}

export interface ChoiceChipsPayload {
  type: 'choiceChips'
  options: { value: string; label: string; primary?: boolean }[]
  onSelect: (value: string) => void
}
export interface ChildFormPayload {
  type: 'childForm'
  title: string
  initial?: Partial<import('$lib/domain/child/schemas').CreateChildInput>
  onSubmit: (input: import('$lib/domain/child/schemas').CreateChildInput) => void
}
export interface DueDatePayload {
  type: 'dueDate'
  title: string
  months: { value: string; label: string }[]
  onConfirm: (month: string) => void
}
export interface SuggestionChipsPayload {
  type: 'suggestions'
  heading?: string
  suggestions: { id: string; label: string; primary?: boolean }[]
  onSelect: (id: string) => void
}

export type ComponentPayload =
  | CarouselPayload | ItemListPayload | GrowthAlertPayload
  | ChoiceChipsPayload | ChildFormPayload | DueDatePayload | SuggestionChipsPayload
```

`Message` inalterado. Verificar chamadores de `ComponentPayload` (chat page) — campos existentes não mudam, só o narrowing por `payload.type`.

### 6.2 Schemas — editar `apps/web/src/lib/domain/child/schemas.ts`

Substituir `CreateChildInputSchema` por:

```ts
export const CreateChildInputSchema = z
  .object({
    name: z.string().min(1, 'Nome é obrigatório').max(80),
    birthDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Data deve estar no formato YYYY-MM-DD').optional(),
    ageMonths: z.number().int().min(0).max(216).optional(),
    currentWeightG: z.number().int().min(0).optional(),
    currentHeightCm: z.number().int().min(0).optional(),
    birthWeightG: z.number().int().min(0, 'Peso não pode ser negativo'),
    birthHeightCm: z.number().int().min(0, 'Altura não pode ser negativa'),
    document: z.string().optional(),
  })
  .refine((c) => c.birthDate !== undefined || c.ageMonths !== undefined, {
    message: 'Informe data de nascimento ou idade',
    path: ['birthDate'],
  })
```

Atualizar `schemas.test.ts`: os casos atuais que passavam `birthDate` continuam válidos; casos novos — só `ageMonths` (ok), nenhum dos dois (falha), `ageMonths: -1` (falha).

### 6.3 Máquina de intake — arquivo novo `apps/web/src/lib/application/chat/IntakeMachine.ts`

```ts
import type { CreateChildInput } from '$lib/domain/child/schemas'

export type IntakeStep =
  | 'ask_has_children' | 'ask_children_count' | 'fill_child_form'
  | 'ask_due_date' | 'explain_platform' | 'ask_search_intent' | 'free_chat'

export type HasChildrenAnswer = 'yes' | 'no' | 'expecting'

export interface IntakeState {
  step: IntakeStep
  hasChildren: HasChildrenAnswer | null
  childrenCount: number | null
  childrenFilled: number
  children: CreateChildInput[]
  dueDate: string | null // YYYY-MM
}

export const initialIntakeState: IntakeState = {
  step: 'ask_has_children',
  hasChildren: null,
  childrenCount: null,
  childrenFilled: 0,
  children: [],
  dueDate: null,
}

export type IntakeEvent =
  | { type: 'ANSWER_HAS_CHILDREN'; answer: HasChildrenAnswer }
  | { type: 'ANSWER_COUNT'; count: number }
  | { type: 'CHILD_SUBMITTED'; child: CreateChildInput }
  | { type: 'DUE_DATE_CONFIRMED'; month: string }
  | { type: 'EXPLANATION_DONE' }
  | { type: 'SEARCH_INTENT_CHOSEN' }

export function reduceIntake(state: IntakeState, event: IntakeEvent): IntakeState {
  switch (event.type) {
    case 'ANSWER_HAS_CHILDREN':
      if (state.step !== 'ask_has_children') return state
      if (event.answer === 'yes') return { ...state, hasChildren: 'yes', step: 'ask_children_count' }
      if (event.answer === 'expecting') return { ...state, hasChildren: 'expecting', step: 'ask_due_date' }
      return { ...state, hasChildren: 'no', step: 'explain_platform' }
    case 'ANSWER_COUNT':
      if (state.step !== 'ask_children_count' || event.count < 1) return state
      return { ...state, childrenCount: event.count, step: 'fill_child_form' }
    case 'CHILD_SUBMITTED': {
      if (state.step !== 'fill_child_form') return state
      const filled = state.childrenFilled + 1
      const children = [...state.children, event.child]
      const done = state.childrenCount !== null && filled >= state.childrenCount
      return { ...state, childrenFilled: filled, children, step: done ? 'explain_platform' : 'fill_child_form' }
    }
    case 'DUE_DATE_CONFIRMED':
      if (state.step !== 'ask_due_date') return state
      return { ...state, dueDate: event.month, step: 'explain_platform' }
    case 'EXPLANATION_DONE':
      if (state.step !== 'explain_platform') return state
      return { ...state, step: 'ask_search_intent' }
    case 'SEARCH_INTENT_CHOSEN':
      if (state.step !== 'ask_search_intent') return state
      return { ...state, step: 'free_chat' }
  }
}
```

Teste novo `IntakeMachine.test.ts`: os 3 ramos completos (yes com count=2 exige 2 CHILD_SUBMITTED; no vai direto a explain; expecting exige DUE_DATE), eventos fora de ordem são no-ops, count<1 é no-op.

### 6.4 Rota — arquivos novos `apps/web/src/routes/agent/+page.server.ts` e `+page.svelte`

`+page.server.ts`: exige sessão (`redirect /login`); se `flags.marketplace` (modo full), `redirect(303, '/chat')`.

`+page.svelte`: fork de `routes/chat/+page.svelte` (ler antes de escrever) com:
- Mesmo transporte SSE/`IChatRepository` e store de mensagens.
- Estado `let intake = $state(initialIntakeState)`; helper `dispatch(event)` que aplica `reduceIntake` e enfileira as mensagens/payloads do próximo passo (textos das chaves `agent.intake.*`).
- Render de `ComponentPayload` por `payload.type`:
  - `choiceChips` → `<ChoiceChipGroup>` (tone outline)
  - `childForm` → `<AgentFormCard title>` com `<ChildInlineForm>`; no submit: `CreateChildInputSchema.parse` → `CreateChild` use case (`IChildRepository`) → `dispatch({ type: 'CHILD_SUBMITTED', child })`
  - `dueDate` → `<AgentFormCard>` com `<MonthPicker>` + confirmar
  - `suggestions` → `<ChoiceChipGroup tone="soft" size="sm">` com heading
- `explain_platform`: mensagem do agente `agent.intake.explain` + auto `EXPLANATION_DONE` após render.
- `ask_search_intent`: sugestões fixas v1 = `bodies_m | winter | party | pajamas | next_size` (labels i18n); escolha envia o texto como mensagem do usuário para o agente e entra em `free_chat`.
- Persistir intake em `sessionStorage bc_intake` (JSON) para sobreviver a reload; hidratar no início.

`routes/chat/+page.server.ts` (criar se não existir): em modo agent, `throw redirect(308, '/agent')`.

**DoD**: fluxo 04→07 do mock reproduzido ponta a ponta em `PUBLIC_APP_MODE=agent`, com crianças persistidas e chat livre funcionando após o intake.

---

## WP7 — i18n

Editar `apps/web/src/lib/i18n/pt.json` e `en.json`. Blocos completos a adicionar (en análogo):

```json
"auth": {
  "register_pf": {
    "back": "Voltar",
    "create_account": "Criar conta",
    "lead": "Leva menos de um minuto",
    "title": "Comece a conversar",
    "title_accent": "com o agente",
    "google": "Registrar com Google",
    "divider": "ou com e-mail",
    "name_label": "Nome completo",
    "name_placeholder": "Maria Clara Santos",
    "email_label": "E-mail",
    "email_placeholder": "voce@email.com",
    "password_label": "Senha",
    "password_placeholder": "Mínimo 8 caracteres",
    "city_label": "Cidade",
    "city_placeholder": "São Paulo, SP",
    "city_hint": "Usada para encontrar itens perto de você",
    "cpf_label": "CPF",
    "cpf_placeholder": "000.000.000-00",
    "submit": "Criar conta",
    "error_pj_disabled": "Cadastro de empresas indisponível no momento.",
    "error_generic": "Não foi possível criar a conta. Tente novamente."
  }
},
"validation": {
  "name_required": "Nome é obrigatório",
  "email_invalid": "E-mail inválido",
  "password_min": "Mínimo 8 caracteres",
  "city_required": "Cidade é obrigatória",
  "cpf_invalid": "CPF inválido — verifique os dígitos"
},
"onboarding": {
  "skip": "Pular",
  "title": "Um agente que",
  "title_accent": "garimpa",
  "title_rest": "o brechó por você",
  "description": "A IA procura roupas e itens ideais combinando tamanho, idade, peso e a sua localização.",
  "features": { "size": "Tamanho", "age": "Idade", "weight": "Peso", "location": "Localização" },
  "cta": "Conversar com o agente"
},
"agent": {
  "topbar": { "name": "Assistente IA", "online": "online", "offline": "offline", "typing": "digitando..." },
  "intake": {
    "greeting": "Oi, {{name}}! Sou o assistente do BabyClothes. Vou te ajudar a encontrar roupinhas ideais em brechós.",
    "has_children": "Pra começar: você tem filhos?",
    "yes": "Sim", "no": "Não", "expecting": "Bebê a caminho",
    "how_many": "Que bom! Quantos filhos você tem?",
    "count_3plus": "3+",
    "child_form_intro": "Perfeito! Me conta sobre ela(e) — preencha os dados abaixo:",
    "child_form_title": "Cadastro da criança",
    "child_saved": "{{name}} cadastrada! Já sei o tamanho ideal.",
    "due_date_intro": "Que alegria! Qual é a previsão de nascimento? Assim já preparo o enxoval no tamanho certo.",
    "due_date_title": "Previsão de nascimento",
    "due_date_confirm": "Confirmar",
    "due_date_saved": "Anotado! Vou sugerir itens RN e P — os tamanhos que recém-nascidos mais usam nos primeiros meses.",
    "explain": "A plataforma funciona assim: eu procuro em brechós roupas e itens ideais combinando tamanho, idade, peso e a sua localização.",
    "search_intent": "Tudo pronto! Agora me conta: o que você quer encontrar? Posso buscar por tipo de peça, ocasião ou estação.",
    "suggestions_heading": "Sugestões",
    "input_placeholder": "Pergunte sobre roupas, tamanhos...",
    "choice_placeholder": "Ou responda por aqui..."
  },
  "suggestions": {
    "bodies_m": "Bodies tamanho M",
    "winter": "Roupas de inverno",
    "party": "Look para festa",
    "pajamas": "Pijamas confortáveis",
    "next_size": "Próximo tamanho (G)"
  },
  "form": {
    "name": "Nome", "age": "Idade", "height": "Altura", "weight": "Peso",
    "birth_height": "Altura ao nascer", "birth_weight": "Peso ao nascer",
    "submit": "Salvar criança"
  }
}
```

**DoD**: nenhuma string nova hardcodada em componente; `en.json` completo com traduções equivalentes.

---

## WP8 — QA final (checklist de aceite)

Executar nos dois modos (`.env` full e `.env.agent`):

| # | Verificação | full | agent |
|---|---|---|---|
| 1 | `/catalog` acessível | ✓ | 303 → `/agent` |
| 2 | `/sell` acessível | ✓ | 303 → `/agent` |
| 3 | BottomNav renderiza | ✓ | ausente |
| 4 | TopBar busca + Publicar | ✓ | ausente (AgentTopBar) |
| 5 | `/register` tela | PF/PJ (RegisterScreen) | PF-only (RegisterPFScreen) |
| 6 | Action aceita `type=pj` | ✓ | fail 400 `pj_disabled` |
| 7 | Pós-registro | `/catalog` | `/onboarding` → `/agent` |
| 8 | `/chat` | ✓ | 308 → `/agent` |
| 9 | Intake: 3 ramos completos | n/a | ✓ (crianças persistidas) |
| 10 | Sugestões clicáveis enviam mensagem | n/a | ✓ |
| 11 | `/profile`, `/child`, `/child/[id]`, `/notifications` | ✓ | ✓ (via avatar/sino) |
| 12 | `check` + `test` (web e design-system) | ✓ | ✓ |
| 13 | Storybook: 6 stories novas renderizam | ✓ | — |
| 14 | grep: zero emojis em código novo; zero `import.meta.env` fora de `env.ts` | ✓ | ✓ |
